using UnityEngine;
using UnityEngine.UI;
using TMPro;

[RequireComponent(typeof(Camera))]
public class CameraConfigurator : MonoBehaviour
{
    private Camera cam;

    [Header("Referencias de UI")]
    public Button projectionButton;
    public TextMeshProUGUI projectionButtonText;

    [Header("Grupos / Paneles")]
    public GameObject perspectiveGroup;
    public GameObject orthographicGroup;

    [Header("Sliders")]
    public Slider fovSlider;
    public Slider sizeSlider;
    public Slider nearClipSlider;
    public Slider farClipSlider;

    void Start()
    {
        cam = GetComponent<Camera>();

        if (fovSlider != null)
        {
            fovSlider.maxValue = 180f;
            fovSlider.value = cam.fieldOfView;
            fovSlider.onValueChanged.AddListener(OnFovChanged);
        }

        if (sizeSlider != null)
        {
            sizeSlider.maxValue = 100f;
            sizeSlider.value = cam.orthographicSize;
            sizeSlider.onValueChanged.AddListener(OnSizeChanged);
        }

        if (nearClipSlider != null)
        {
            nearClipSlider.maxValue = 100f;
            nearClipSlider.value = cam.nearClipPlane;
            nearClipSlider.onValueChanged.AddListener(OnNearClipChanged);
        }

        if (farClipSlider != null)
        {
            farClipSlider.maxValue = 1000f;
            farClipSlider.value = cam.farClipPlane;
            farClipSlider.onValueChanged.AddListener(OnFarClipChanged);
        }

        if (projectionButton != null)
        {
            projectionButton.onClick.AddListener(ToggleProjection);
        }

        UpdateUIState();
    }

    public void ToggleProjection()
    {
        cam.orthographic = !cam.orthographic;
        UpdateUIState();
    }

    void UpdateUIState()
    {
        if (cam.orthographic)
        {
            if (perspectiveGroup != null) perspectiveGroup.SetActive(false);
            if (orthographicGroup != null) orthographicGroup.SetActive(true);
            if (projectionButtonText != null) projectionButtonText.text = "Modo: Orthographic";
        }
        else
        {
            if (perspectiveGroup != null) perspectiveGroup.SetActive(true);
            if (orthographicGroup != null) orthographicGroup.SetActive(false);
            if (projectionButtonText != null) projectionButtonText.text = "Modo: Perspective";
        }
    }

    void OnFovChanged(float value) => cam.fieldOfView = value;
    void OnSizeChanged(float value) => cam.orthographicSize = value;
    void OnNearClipChanged(float value) => cam.nearClipPlane = value;
    void OnFarClipChanged(float value) => cam.farClipPlane = value;

    void OnDrawGizmos()
    {
        if (cam == null)
            cam = GetComponent<Camera>();

        Gizmos.color = Color.yellow;
        Gizmos.matrix = Matrix4x4.TRS(transform.position, transform.rotation, Vector3.one);

        float currentFov = cam.orthographic ? 60f : cam.fieldOfView;
        Gizmos.DrawFrustum(Vector3.zero, currentFov, cam.farClipPlane, cam.nearClipPlane, cam.aspect);
    }
}