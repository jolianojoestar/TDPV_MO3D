using UnityEngine;

public class CubeBehaviour : MonoBehaviour
{
    public float rotationSpeed = 90f;

    private int rotationDirection = 0;

    void Update()
    {
        transform.Rotate(
            Vector3.up * rotationDirection * rotationSpeed * Time.deltaTime
        );
    }

    public void RotateClockwise()
    {
        rotationDirection = 1;
    }

    public void RotateCounterClockwise()
    {
        rotationDirection = -1;
    }

    public void StopRotation()
    {
        rotationDirection = 0;
    }
}