using UnityEngine;

public class CubeController : MonoBehaviour
{
    private CubeBehaviour cubeBehaviour;

    void Start()
    {
        cubeBehaviour = GetComponent<CubeBehaviour>();
    }

    public void OnRotateRight()
    {
        cubeBehaviour.RotateClockwise();
    }

    public void OnRotateLeft()
    {
        cubeBehaviour.RotateCounterClockwise();
    }

    public void OnStopRotation()
    {
        cubeBehaviour.StopRotation();
    }
}