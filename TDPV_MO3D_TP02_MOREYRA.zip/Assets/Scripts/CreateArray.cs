using UnityEngine;

public class CreateArray : MonoBehaviour
{
    public GameObject blockPrefab;

    public int N = 3;
    public int M = 4;

    void Start()
    {
        // por las dudas reviso que est� asignado el prefab y que las medidas sean validas
        if (blockPrefab == null || N <= 0 || M <= 0)
        {
            Debug.LogError("Assign a prefab and valid dimensions.");
            return;
        }

        // creo el primer bloque en el origen **
        GameObject firstBlock = Instantiate(blockPrefab,Vector3.zero,Quaternion.identity);

        // busco los renderers de los objetos que estan dentro del prefab
        Renderer[] renderers =
            firstBlock.GetComponentsInChildren<Renderer>();

        if (renderers.Length == 0)
        {
            Debug.LogError("The prefab has no Renderer components.");
            Destroy(firstBlock);
            return;
        }

        Bounds blockBounds = renderers[0].bounds;

        // esto me sirvi� para encapsular todos los bounds de los renderers del prefab
        foreach (Renderer renderer in renderers)
        {
            blockBounds.Encapsulate(renderer.bounds);
        }

        // saco el ancho y el alto que ocupa el bloque para calcular la separacion
        float blockWidth = blockBounds.size.x;
        float blockHeight = blockBounds.size.y;

        // recorro los ejes x e y para ir armando la pared
        for (int x = 0; x < N; x++)
        {
            for (int y = 0; y < M; y++)
            {
                // ** el primero ya lo cree arriba, asi que salto esa posicion
                if (x == 0 && y == 0)
                {
                    continue;
                }

                // calculo donde va cada bloque segun la fila y la columna
                Vector3 position = new Vector3(x * blockWidth,y * blockHeight,0f);

                // creo una copia del prefab en la posicion que calcule
                Instantiate(blockPrefab,position,Quaternion.identity);
            }
        }
    }
}